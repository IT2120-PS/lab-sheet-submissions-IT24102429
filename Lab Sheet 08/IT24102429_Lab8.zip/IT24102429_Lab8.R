setwd("C:\\Users\\l\\Desktop\\SLIIT\\Y2S1\\PS\\Lab\\Lab 8")

weights  <- scan("Exercise - LaptopsWeights.txt", what = numeric(), skip = 1)

# Question 1:
# Calculate the population mean and population standard deviation

pop_mean_w <- mean(weights)
pop_var_w  <- sum((weights - pop_mean_w)^2) / length(weights)
pop_sd_w   <- sqrt(pop_var_w)

pop_mean_w
pop_var_w    
pop_sd_w 

# Question 2:
# Draw 25 random samples of size 6 (with replacement) and calculate the sample
# mean and sample standard deviation for each sample.

set.seed(123)

w_sample_means <- replicate(25, mean(sample(weights, size = 6, replace = TRUE)))
w_sample_sds   <- replicate(25, sd(sample(weights, size = 6, replace = TRUE)))

w_sample_means
w_sample_sds

# Question 3:
# Calculate the mean and standard deviation of the 25 sample means

mean_sample_means <- mean(w_sample_means)

sd_sample_means   <- sd(w_sample_means)

mean_sample_means
sd_sample_means

pop_sd_w / sqrt(6)

