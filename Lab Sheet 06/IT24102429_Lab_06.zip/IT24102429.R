#Question 01
n <- 50
p <- 0.85

# i)
# Binomial (n = 50, p = 0.85)

# ii)
1-pbinom(46, 50, 0.85, lower.tail = TRUE)

#Question 02

# i) 
# Random variable = number of customer calls per hour

#ii)
# Poisson distribution with lambda = 12

#iii)
dpois(15, 12)
